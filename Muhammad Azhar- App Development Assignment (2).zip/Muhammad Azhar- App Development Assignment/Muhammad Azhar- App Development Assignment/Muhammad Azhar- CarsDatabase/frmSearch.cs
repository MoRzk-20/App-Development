﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDatabase
{
    public partial class frmSearch : Form
    {
        public frmSearch()
        {
            InitializeComponent();
        }
       
        private void frmSearch_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hireDataSet.TblCars' table. You can move, or remove it, as needed.
            this.tblCarsTableAdapter.Fill(this.hireDataSet.TblCars);

           
            string[] fieldNames = { "Make", "EngineSize", "RentalPerDay", "Available" };
            Field.DataSource = fieldNames;

       
            string[] operatorSymbols = { "=", "<", ">", "<=", ">=" };
            Operator.DataSource = operatorSymbols;
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            if (Field.SelectedItem != null && Operator.SelectedItem != null && !string.IsNullOrEmpty(SearchValue.Text))
            {
                string selectedField = Field.SelectedItem.ToString();
                string selectedOperator = Operator.SelectedItem.ToString();
                string searchValue = SearchValue.Text;

                // Handle the "Available" field separately
                if (selectedField == "Available" && (searchValue == "Yes" || searchValue == "No"))
                {
                    searchValue = (searchValue == "Yes") ? "1" : "0";
                }

                string query = $"SELECT * FROM tblCars WHERE {selectedField} {selectedOperator} @SearchValue";

                try
                {
                    using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Hire.mdf;Integrated Security=True "))
                    {
                        connection.Open();

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@SearchValue", searchValue);

                            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                            {
                                DataTable dataTable = new DataTable();
                                adapter.Fill(dataTable);

                                Results.DataSource = dataTable;

                                if (dataTable.Rows.Count == 0)
                                {
                                    MessageBox.Show("No matching records found.");
                                }
                            }
                        }
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please enter criteria in all three controls.");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            
            this.Hide();

            // Show the frmCars form (assuming it's an instance of FrmCars)
            frmCars frmCars = new frmCars();
            frmCars.Show();
        }

        private void txtSearchValue_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
