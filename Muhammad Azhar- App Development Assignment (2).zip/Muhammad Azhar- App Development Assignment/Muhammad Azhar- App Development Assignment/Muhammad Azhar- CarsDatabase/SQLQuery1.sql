﻿insert into TblCars(VehicleRegNo, Make, EngineSize, DateReg, RentalPerDay, Available)
Values
	('BV557UTR','Mazda','1.6L','20070612',90,0),
('GH376DRS','Ford','1.6L','20070413',95,1),
('GV022JFG','Ford','1.4L','20060823',65,0),
('HR483GHT','Honda','1.4L','20060324',75,0),
('JK458YGD','Mercedes','1.6L','20070215',120,0),
('KR385FWR','Nissan','1.4L','20060910',65,1),
('PL324GHT','Nissan','1.2L','20060821',55,0),
('PQ127RET','Fiat','1.4L','20070421',80,0),
('PR674FHD','Ford','1.2L','20060804',60,0),
('RK389TFW','Ford','1.6L','20070719',120,0),
('RT543FRD','Fiat','1.4L','20060823',75,0),
('TH237TPL','Mercedes','1.6L','20070108',110,1),
('YR149HGE','Honda','1.4L','20070419',85,0),
('YW903TFY','Honda','1.4L','20060605',70,1),
('YZ782HJK','Mercedes','1.4L','20060912',95,0)