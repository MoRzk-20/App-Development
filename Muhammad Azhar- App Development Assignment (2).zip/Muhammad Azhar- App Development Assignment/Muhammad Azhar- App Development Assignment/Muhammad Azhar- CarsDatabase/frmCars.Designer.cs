﻿namespace CarDatabase
{
    partial class frmCars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Availability = new System.Windows.Forms.CheckBox();
            this.tblCarsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hireDataSet = new CarDatabase.HireDataSet();
            this.Update = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.Search = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.VehicleRegistrationNumber = new System.Windows.Forms.TextBox();
            this.Make = new System.Windows.Forms.TextBox();
            this.EngineSize = new System.Windows.Forms.TextBox();
            this.DateRegistration = new System.Windows.Forms.TextBox();
            this.RentalPerDay = new System.Windows.Forms.TextBox();
            this.tblCarsTableAdapter = new CarDatabase.HireDataSetTableAdapters.TblCarsTableAdapter();
            this.tableAdapterManager = new CarDatabase.HireDataSetTableAdapters.TableAdapterManager();
            this.First = new System.Windows.Forms.Button();
            this.Previous = new System.Windows.Forms.Button();
            this.Next = new System.Windows.Forms.Button();
            this.Last = new System.Windows.Forms.Button();
            this.Count = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblVehicleRegNO = new System.Windows.Forms.Label();
            this.lblMake = new System.Windows.Forms.Label();
            this.lblEngineSize = new System.Windows.Forms.Label();
            this.lblDateRegistration = new System.Windows.Forms.Label();
            this.lblRentalPerDay = new System.Windows.Forms.Label();
            this.lblAvailable = new System.Windows.Forms.Label();
            this.Tooltip1Available = new System.Windows.Forms.ToolTip(this.components);
            this.tooltipRentalPerDay = new System.Windows.Forms.ToolTip(this.components);
            this.tooltipDateReg = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.tblCarsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hireDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // Availability
            // 
            this.Availability.AutoSize = true;
            this.Availability.BackColor = System.Drawing.Color.Transparent;
            this.Availability.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.tblCarsBindingSource, "Available", true));
            this.Availability.Location = new System.Drawing.Point(266, 180);
            this.Availability.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Availability.Name = "Availability";
            this.Availability.Size = new System.Drawing.Size(15, 14);
            this.Availability.TabIndex = 0;
            this.Availability.Tag = "";
            this.Tooltip1Available.SetToolTip(this.Availability, "The checkbox represents the availablity of the car selected.");
            this.Availability.UseVisualStyleBackColor = false;
            // 
            // tblCarsBindingSource
            // 
            this.tblCarsBindingSource.DataMember = "TblCars";
            this.tblCarsBindingSource.DataSource = this.hireDataSet;
            // 
            // hireDataSet
            // 
            this.hireDataSet.DataSetName = "HireDataSet";
            this.hireDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Update
            // 
            this.Update.ForeColor = System.Drawing.Color.Black;
            this.Update.Location = new System.Drawing.Point(465, 29);
            this.Update.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(60, 28);
            this.Update.TabIndex = 1;
            this.Update.Text = "Update";
            this.Update.UseVisualStyleBackColor = true;
            this.Update.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // Add
            // 
            this.Add.ForeColor = System.Drawing.Color.ForestGreen;
            this.Add.Location = new System.Drawing.Point(465, 61);
            this.Add.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(60, 27);
            this.Add.TabIndex = 2;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // Delete
            // 
            this.Delete.ForeColor = System.Drawing.Color.Red;
            this.Delete.Location = new System.Drawing.Point(465, 92);
            this.Delete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(58, 27);
            this.Delete.TabIndex = 3;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // Search
            // 
            this.Search.ForeColor = System.Drawing.Color.DarkGreen;
            this.Search.Location = new System.Drawing.Point(466, 125);
            this.Search.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(59, 27);
            this.Search.TabIndex = 4;
            this.Search.Text = "Search";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // Cancel
            // 
            this.Cancel.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.Cancel.Location = new System.Drawing.Point(465, 156);
            this.Cancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(59, 27);
            this.Cancel.TabIndex = 5;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // Exit
            // 
            this.Exit.ForeColor = System.Drawing.Color.Red;
            this.Exit.Location = new System.Drawing.Point(464, 187);
            this.Exit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(59, 27);
            this.Exit.TabIndex = 6;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // VehicleRegistrationNumber
            // 
            this.VehicleRegistrationNumber.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCarsBindingSource, "VehicleRegNo", true));
            this.VehicleRegistrationNumber.Location = new System.Drawing.Point(266, 69);
            this.VehicleRegistrationNumber.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.VehicleRegistrationNumber.Name = "VehicleRegistrationNumber";
            this.VehicleRegistrationNumber.Size = new System.Drawing.Size(68, 20);
            this.VehicleRegistrationNumber.TabIndex = 7;
            // 
            // Make
            // 
            this.Make.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCarsBindingSource, "Make", true));
            this.Make.Location = new System.Drawing.Point(266, 89);
            this.Make.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Make.Name = "Make";
            this.Make.Size = new System.Drawing.Size(68, 20);
            this.Make.TabIndex = 8;
            // 
            // EngineSize
            // 
            this.EngineSize.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCarsBindingSource, "EngineSize", true));
            this.EngineSize.Location = new System.Drawing.Point(266, 110);
            this.EngineSize.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.EngineSize.Name = "EngineSize";
            this.EngineSize.Size = new System.Drawing.Size(68, 20);
            this.EngineSize.TabIndex = 9;
            // 
            // DateRegistration
            // 
            this.DateRegistration.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCarsBindingSource, "DateReg", true));
            this.DateRegistration.Location = new System.Drawing.Point(266, 132);
            this.DateRegistration.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DateRegistration.Name = "DateRegistration";
            this.DateRegistration.Size = new System.Drawing.Size(68, 20);
            this.DateRegistration.TabIndex = 10;
            this.tooltipDateReg.SetToolTip(this.DateRegistration, "This is the date that the vehicle is registed");
            // 
            // RentalPerDay
            // 
            this.RentalPerDay.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCarsBindingSource, "RentalPerDay", true));
            this.RentalPerDay.Location = new System.Drawing.Point(266, 153);
            this.RentalPerDay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RentalPerDay.Name = "RentalPerDay";
            this.RentalPerDay.Size = new System.Drawing.Size(68, 20);
            this.RentalPerDay.TabIndex = 11;
            this.tooltipRentalPerDay.SetToolTip(this.RentalPerDay, "The amount to hire a car per day");
            // 
            // tblCarsTableAdapter
            // 
            this.tblCarsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TblCarsTableAdapter = this.tblCarsTableAdapter;
            this.tableAdapterManager.UpdateOrder = CarDatabase.HireDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // First
            // 
            this.First.ForeColor = System.Drawing.Color.Black;
            this.First.Location = new System.Drawing.Point(112, 293);
            this.First.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.First.Name = "First";
            this.First.Size = new System.Drawing.Size(63, 25);
            this.First.TabIndex = 12;
            this.First.Text = "First";
            this.First.UseVisualStyleBackColor = true;
            this.First.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // Previous
            // 
            this.Previous.ForeColor = System.Drawing.Color.Black;
            this.Previous.Location = new System.Drawing.Point(178, 293);
            this.Previous.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Previous.Name = "Previous";
            this.Previous.Size = new System.Drawing.Size(63, 25);
            this.Previous.TabIndex = 13;
            this.Previous.Text = "Previous";
            this.Previous.UseVisualStyleBackColor = true;
            this.Previous.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // Next
            // 
            this.Next.ForeColor = System.Drawing.Color.Black;
            this.Next.Location = new System.Drawing.Point(356, 296);
            this.Next.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(63, 25);
            this.Next.TabIndex = 14;
            this.Next.Text = "Next";
            this.Next.UseVisualStyleBackColor = true;
            this.Next.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // Last
            // 
            this.Last.ForeColor = System.Drawing.Color.Black;
            this.Last.Location = new System.Drawing.Point(434, 296);
            this.Last.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Last.Name = "Last";
            this.Last.Size = new System.Drawing.Size(63, 25);
            this.Last.TabIndex = 15;
            this.Last.Text = "Last";
            this.Last.UseVisualStyleBackColor = true;
            this.Last.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // Count
            // 
            this.Count.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Count.Location = new System.Drawing.Point(266, 296);
            this.Count.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Count.Name = "Count";
            this.Count.Size = new System.Drawing.Size(68, 20);
            this.Count.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Maiandra GD", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(209, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 26);
            this.label1.TabIndex = 17;
            this.label1.Text = "Bowman Car Hire";
            // 
            // lblVehicleRegNO
            // 
            this.lblVehicleRegNO.AutoSize = true;
            this.lblVehicleRegNO.BackColor = System.Drawing.Color.Transparent;
            this.lblVehicleRegNO.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVehicleRegNO.Location = new System.Drawing.Point(22, 69);
            this.lblVehicleRegNO.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVehicleRegNO.Name = "lblVehicleRegNO";
            this.lblVehicleRegNO.Size = new System.Drawing.Size(185, 18);
            this.lblVehicleRegNO.TabIndex = 18;
            this.lblVehicleRegNO.Text = "Vehicle Registration Number:";
            // 
            // lblMake
            // 
            this.lblMake.AutoSize = true;
            this.lblMake.BackColor = System.Drawing.Color.Transparent;
            this.lblMake.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMake.Location = new System.Drawing.Point(22, 92);
            this.lblMake.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMake.Name = "lblMake";
            this.lblMake.Size = new System.Drawing.Size(45, 18);
            this.lblMake.TabIndex = 19;
            this.lblMake.Text = "Make:";
            // 
            // lblEngineSize
            // 
            this.lblEngineSize.AutoSize = true;
            this.lblEngineSize.BackColor = System.Drawing.Color.Transparent;
            this.lblEngineSize.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngineSize.Location = new System.Drawing.Point(23, 113);
            this.lblEngineSize.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEngineSize.Name = "lblEngineSize";
            this.lblEngineSize.Size = new System.Drawing.Size(79, 18);
            this.lblEngineSize.TabIndex = 20;
            this.lblEngineSize.Text = "Engine Size:";
            // 
            // lblDateRegistration
            // 
            this.lblDateRegistration.AutoSize = true;
            this.lblDateRegistration.BackColor = System.Drawing.Color.Transparent;
            this.lblDateRegistration.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateRegistration.Location = new System.Drawing.Point(23, 132);
            this.lblDateRegistration.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDateRegistration.Name = "lblDateRegistration";
            this.lblDateRegistration.Size = new System.Drawing.Size(117, 18);
            this.lblDateRegistration.TabIndex = 21;
            this.lblDateRegistration.Text = "Date Registration:";
            // 
            // lblRentalPerDay
            // 
            this.lblRentalPerDay.AutoSize = true;
            this.lblRentalPerDay.BackColor = System.Drawing.Color.Transparent;
            this.lblRentalPerDay.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRentalPerDay.Location = new System.Drawing.Point(23, 154);
            this.lblRentalPerDay.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRentalPerDay.Name = "lblRentalPerDay";
            this.lblRentalPerDay.Size = new System.Drawing.Size(101, 18);
            this.lblRentalPerDay.TabIndex = 22;
            this.lblRentalPerDay.Text = "Rental Per Day:";
            // 
            // lblAvailable
            // 
            this.lblAvailable.AutoSize = true;
            this.lblAvailable.BackColor = System.Drawing.Color.Transparent;
            this.lblAvailable.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvailable.Location = new System.Drawing.Point(22, 180);
            this.lblAvailable.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAvailable.Name = "lblAvailable";
            this.lblAvailable.Size = new System.Drawing.Size(65, 18);
            this.lblAvailable.TabIndex = 23;
            this.lblAvailable.Text = "Available:";
            // 
            // tooltipDateReg
            // 
            this.tooltipDateReg.ShowAlways = true;
            // 
            // frmCars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BackgroundImage = global::CarDatabase.Properties.Resources.gradient_blue_background_free_vector;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(576, 369);
            this.Controls.Add(this.lblAvailable);
            this.Controls.Add(this.lblRentalPerDay);
            this.Controls.Add(this.lblDateRegistration);
            this.Controls.Add(this.lblEngineSize);
            this.Controls.Add(this.lblMake);
            this.Controls.Add(this.lblVehicleRegNO);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Count);
            this.Controls.Add(this.Last);
            this.Controls.Add(this.Next);
            this.Controls.Add(this.Previous);
            this.Controls.Add(this.First);
            this.Controls.Add(this.RentalPerDay);
            this.Controls.Add(this.DateRegistration);
            this.Controls.Add(this.EngineSize);
            this.Controls.Add(this.Make);
            this.Controls.Add(this.VehicleRegistrationNumber);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.Availability);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmCars";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TaskA Azhar 14/10/2024";
            this.Load += new System.EventHandler(this.frmCars_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tblCarsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hireDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox Availability;
        private System.Windows.Forms.Button Update;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.TextBox VehicleRegistrationNumber;
        private System.Windows.Forms.TextBox Make;
        private System.Windows.Forms.TextBox EngineSize;
        private System.Windows.Forms.TextBox DateRegistration;
        private System.Windows.Forms.TextBox RentalPerDay;
        private HireDataSet hireDataSet;
        private System.Windows.Forms.BindingSource tblCarsBindingSource;
        private HireDataSetTableAdapters.TblCarsTableAdapter tblCarsTableAdapter;
        private HireDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button First;
        private System.Windows.Forms.Button Previous;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Button Last;
        private System.Windows.Forms.TextBox Count;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblVehicleRegNO;
        private System.Windows.Forms.Label lblMake;
        private System.Windows.Forms.Label lblEngineSize;
        private System.Windows.Forms.Label lblDateRegistration;
        private System.Windows.Forms.Label lblRentalPerDay;
        private System.Windows.Forms.Label lblAvailable;
        private System.Windows.Forms.ToolTip Tooltip1Available;
        private System.Windows.Forms.ToolTip tooltipRentalPerDay;
        private System.Windows.Forms.ToolTip tooltipDateReg;
    }
}