﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//Azhar Razak Cars Database
namespace CarDatabase
{
    public partial class frmCars : Form
    {
        public frmCars()
        {
            InitializeComponent();
        }
        private void UpdateRecordCount()
        {
            int totalRecords = tblCarsBindingSource.Count;
            int currentRecord = tblCarsBindingSource.Position + 1; // Position is 0-based

            Count.Text = currentRecord + " / " + totalRecords;
        }
        private void frmCars_Load(object sender, EventArgs e)
        {
            // Data is loaded into the 'hireDataSet.TblCars' table using this piece of code. As needed, you can relocate or remove it.
            this.tblCarsTableAdapter.Fill(this.hireDataSet.TblCars);

          

        
        }
        // Update
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Hire.mdf;Integrated Security=True"))
                {
                    connection.Open();

                    string updateQuery = "UPDATE tblcars " +
                                        "SET Make = @Make, " +
                                        "EngineSize = @EngineSize, " +
                                        "DateReg = @DateReg, " +
                                        "RentalPerDay = @RentalPerDay, " +
                                        "Available = @Available " +
                                        "WHERE VehicleRegNo = @VehicleRegNo";

                    using (SqlCommand command = new SqlCommand(updateQuery, connection))
                    {
                        // Parameters are set according to the textboxes and checkbox
                        command.Parameters.AddWithValue("@Make", Make.Text);
                        command.Parameters.AddWithValue("@EngineSize", EngineSize.Text);
                        command.Parameters.AddWithValue("@DateReg", DateTime.Parse(DateRegistration.Text));
                        command.Parameters.AddWithValue("@RentalPerDay", Convert.ToDecimal(RentalPerDay.Text));
                        command.Parameters.AddWithValue("@Available", Availability.Checked);
                        command.Parameters.AddWithValue("@VehicleRegNo", VehicleRegistrationNumber.Text);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record updated successfully.");
                        }
                        else
                        {
                            MessageBox.Show("No records were updated.");
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        //Add
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Hire.mdf;Integrated Security=True"))
                {
                    connection.Open();

                    // Create the SQL INSERT statement
                    string insertQuery = "INSERT INTO tblcars (VehicleRegNo, Make, EngineSize, DateReg, RentalPerDay, Available) " +
                                        "VALUES (@VehicleRegNo, @Make, @EngineSize, @DateReg, @RentalPerDay, @Available)";

                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // Set parameters based on the input fields
                        command.Parameters.AddWithValue("@VehicleRegNo", VehicleRegistrationNumber.Text);
                        command.Parameters.AddWithValue("@Make", Make.Text);
                        command.Parameters.AddWithValue("@EngineSize", EngineSize.Text);
                        command.Parameters.AddWithValue("@DateReg", DateTime.Parse(DateRegistration.Text));
                        command.Parameters.AddWithValue("@RentalPerDay", Convert.ToDecimal(RentalPerDay.Text));
                        command.Parameters.AddWithValue("@Available", Availability.Checked);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record added successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Addition failed.");
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        // Delete
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Hire.mdf;Integrated Security=True"))
                {
                    connection.Open();

                    // Create the SQL DELETE statement
                    string deleteQuery = "DELETE FROM tblcars WHERE VehicleRegNo = @VehicleRegNo";

                    using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                    {
                        // Set the parameter for the VehicleRegNo based on the input field
                        command.Parameters.AddWithValue("@VehicleRegNo", VehicleRegistrationNumber.Text);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record deleted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("No records were deleted.");
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        // Cancel
        private void btnCancel_Click(object sender, EventArgs e)
        {

            VehicleRegistrationNumber.Text = string.Empty;
            Make.Text = string.Empty;
            EngineSize.Text = string.Empty;
            DateRegistration.Text = string.Empty;
            RentalPerDay.Text = string.Empty;
            Availability.Checked = false;


            MessageBox.Show("Changes canceled");


        }
        // Exit
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // Next
        private void btnNext_Click(object sender, EventArgs e)
        {
            if (tblCarsBindingSource.Position + 1 < tblCarsBindingSource.Count)
                tblCarsBindingSource.MoveNext();
            UpdateRecordCount(); // Update the record count after moving
        }
        // First
        private void btnFirst_Click(object sender, EventArgs e)
        {
            tblCarsBindingSource.MoveFirst();
            UpdateRecordCount();
        }
        //Previous
        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (tblCarsBindingSource.Position - 1 >= 0)
                tblCarsBindingSource.MovePrevious();
            UpdateRecordCount();
        }
        // Last
        private void btnLast_Click(object sender, EventArgs e)
        {
            tblCarsBindingSource.Position = tblCarsBindingSource.Count - 1;
            UpdateRecordCount();
        }
        // Search
        private void btnSearch_Click(object sender, EventArgs e)
        {

            frmSearch frmSearch = new frmSearch();
            frmSearch.Show();
            this.Hide();

        }

        
    }
}